# Auction_House
<<<<<<< HEAD
Analysis of WoW Auction House Prices

I focused on a specific crafting niche in the WoW Auction house, that being
embellishment items, and finding which crafted components were the most profitable 
and which profession would be the best to choose to operate in this niche.

I began with the raw data 'commodities.csv', which was far too large for my machine, 
and wittled it down to only include the items necissary for each craft, subdivided by 
profession. 
I then constructed DataFrame 'profiles' of each component, comparing the cost of 
the component to the material cost to craft the item. After this, I opted to drop 
jewelcrafting as an option due to a large outlier in our data, and I chose the most 
profitable component among each profession and compared them.
=======
## Analysis of WoW Auction House Activity
- The Main csv file (6.6 mb) contains 79,852,830 records from hourly pulls From Dec 22 2023 to Jan 03 2024
- Each record has 8 columns
  - id,
  - quantity,
  - unit_price,
  - time_left,
  - item.id,
  - item.name,
  - item.class,
  - datetime
- There where no NaN values found

## 4 Team mates, 4 different approaches

### Fidel
- Distribution of auction records by class
- Distribution of unique items by class
- What has flooded the auction and what has less competition ?

### Griffin
- Current Crafting Profitability by Profession/Trade
- What are the best options ?

### Michael
- Ratio of "Item Bloat" with Junk items in the Game
- Are there a lot of Junk items in the Game ?

### Robert
- Analysis of trending profitably by profession and forecast for new players or returning players starting a new Character
- What professions to choose ? 
>>>>>>> c4c34543803211d9679d41b12aee98a0ea49b841
